Placer le répertoire 
C:\DsiChuCaenPowerShell\trunk\Modules\NTFSSecurity\NTFSSecurity 
dans 
C:\WINDOWS\system32\WindowsPowerShell\v1.0\Modules

Supprimer l'ancien C:\WINDOWS\system32\WindowsPowerShell\v1.0\Modules\NTFSSecurity si déjà présent